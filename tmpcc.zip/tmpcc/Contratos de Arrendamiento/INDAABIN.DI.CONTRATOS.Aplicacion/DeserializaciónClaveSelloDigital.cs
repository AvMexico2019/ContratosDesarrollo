﻿using System.Runtime.Serialization;

namespace INDAABIN.DI.CONTRATOS.Aplicacion
{
    // esta clase se usa para deserealizar la cadena de webconfig que contiene las
    // claves de sello digital
    [DataContract]
    public class DeserializaciónClaveSelloDigital
    {
        [DataMember]
        public string FechaAlta;  // formato YYYY-mm-dd

        [DataMember]
        public string Clave;

        public string ToCadena()
        {
            return FechaAlta + ":" + Clave;
        }
    }
}