SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Raymundo Peralta
-- Create date: 2019-11-26
-- Description:	Entrega el valor siguiente del folio universal
-- =============================================
IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NextFolioUnivertsal]') AND type = 'P')
begin
	Drop Procedure [dbo].[NextFolioUnivertsal]
end
go
Create Procedure NextFolioUnivertsal
AS
BEGIN
	declare @next bigint;
	SELECT @next = Convert(BIGINT,current_value) FROM sys.sequences WHERE name = 'ContratosFolioUniversal';
	(SELECT  NEXT  VALUE FOR [dbo].[ContratosFolioUniversal]);
	return @next
END
GO

