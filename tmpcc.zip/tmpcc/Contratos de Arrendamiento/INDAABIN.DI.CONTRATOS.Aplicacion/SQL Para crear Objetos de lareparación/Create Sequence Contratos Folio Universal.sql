USE [ArrendamientoInmueble]
GO

USE [ArrendamientoInmueble]
GO

/****** Object:  Sequence [dbo].[ContratosFolioUniversal]    Script Date: 26/11/2019 04:30:50 p. m. ******/
IF NOT EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ContratosFolioUniversal]') AND type = 'SO')
CREATE SEQUENCE [dbo].[ContratosFolioUniversal] 
 AS [bigint]
 START WITH 50000
 INCREMENT BY 1
 MINVALUE 50000
 MAXVALUE 9223372036854775807
 NO CACHE 
GO


