﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace INDAABIN.DI.CONTRATOS.ModeloNegocios
{
    public class SolicitudOpinion
    {
        public Nacional Nacional
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int IdSolOpinion
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
