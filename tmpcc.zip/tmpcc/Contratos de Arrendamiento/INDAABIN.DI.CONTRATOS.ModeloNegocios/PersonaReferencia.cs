﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace INDAABIN.DI.CONTRATOS.ModeloNegocios
{
    public class PersonaReferencia
    {
        public int IdPersonaRef
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public String Nombre
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public String Ap1
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public String Ap2
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public string Email
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public string Obs
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public string TipoPersonaRef
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public ContratoArrto ContratoArrto
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
