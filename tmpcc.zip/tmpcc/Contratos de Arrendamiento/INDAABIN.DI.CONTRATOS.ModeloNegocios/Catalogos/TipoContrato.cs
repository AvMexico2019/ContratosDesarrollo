﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INDAABIN.DI.CONTRATOS.ModeloNegocios
{

    //nacional, Extranjero, Otras Fig
    public class TipoContrato
    {
        public byte IdTipoContrato { get; set; }
        public string DescripcionTipoContrato { get; set; }
    
    }
}
