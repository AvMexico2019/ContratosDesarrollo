﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INDAABIN.DI.CONTRATOS.ModeloNegocios
{
    public class TipoArrendamiento
    {
        public byte IdTipoArrendamiento { get; set; }
        public string DescTipoArrendamiento { get; set; }


    }
}
