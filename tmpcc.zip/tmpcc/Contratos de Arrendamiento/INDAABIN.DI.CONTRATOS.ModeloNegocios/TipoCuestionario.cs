﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace INDAABIN.DI.CONTRATOS.ModeloNegocios
{
    public class TipoCuestionario
    {
        public int IdTipoCuestionario
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
