﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INDAABIN.DI.CONTRATOS.ModeloNegocios
{
    public class Constantes
    {
        public const string IdAplicacionSSO = "3";
        public const string IndenParametroEncrip = "data";
        public const int IdMexico = 165;
        public const decimal MONTO_MINIMO_SECUENCIAL = 7130;
    }
}
