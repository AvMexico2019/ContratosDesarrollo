﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace INDAABIN.DI.CONTRATOS.ModeloNegocios
{
    public class Cuestionario
    {
        public TipoCuestionario TipoCuestionario
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public Pregunta Pregunta
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int IdCuestionario
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
