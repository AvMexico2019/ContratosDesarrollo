﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace INDAABIN.DI.CONTRATOS.ModeloNegocios
{
    public class Tema
    {
        public int IdTema
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int NombreTema
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
