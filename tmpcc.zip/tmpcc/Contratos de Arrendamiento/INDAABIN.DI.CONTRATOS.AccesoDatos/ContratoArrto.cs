﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using System.Transactions;
//comunicacion con las capas
using INDAABIN.DI.CONTRATOS.Datos;
using INDAABIN.DI.CONTRATOS.ModeloNegocios;


namespace INDAABIN.DI.CONTRATOS.AccesoDatos
{
    public class ContratoArrto
    {

  
    }
}
